<?php namespace WppSkeleton\Http\Requests;

use Illuminate\Http\Request as PluginRequest;

abstract class Request extends PluginRequest
{
    //
}
