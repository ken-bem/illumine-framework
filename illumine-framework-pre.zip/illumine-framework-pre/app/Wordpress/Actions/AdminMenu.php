<?php
/**
 * @var \IllumineFramework\WpSettings $admin
 * @var \Illuminate\Config\Repository $config
 **/


//    $admin->addPanel(
//        'Illumine Framework', //$page_title
//        'Illumine Framework', //$menu_title
//        'manage_options', //$capability
//        'wpp_skeleton_illumine', //$menu_slug
//        'WppSkeleton\Http\Controllers\WpAdminController@load'
//    );


