<?php if(!defined('ABSPATH')){ die(); }

/**
 * Obtain Plugin Instance.
 * Gee, that was easy!
 */

IllumineFramework\IlluminePlugin::getInstance();