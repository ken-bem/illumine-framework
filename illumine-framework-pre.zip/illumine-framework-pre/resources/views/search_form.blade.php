<div style="text-align: center;">
    <h3>Search Plugins</h3>
    <form action="/wordpress-plugins/" method="get">
        <input type="search" name="post_title" value="{{ $searchTerm }}" placeholder="{{ $searchTerm }}">
    </form>
</div>